import XCTest

import UDocsDocumentModelTests

var tests = [XCTestCaseEntry]()
tests += UDocsDocumentModelTests.allTests()
XCTMain(tests)
