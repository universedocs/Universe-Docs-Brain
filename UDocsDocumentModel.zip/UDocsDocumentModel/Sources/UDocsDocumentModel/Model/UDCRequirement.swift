//
//  UDCRequirementDocumentObject.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 12/11/18.
//

import Foundation

public class UDCRequirement : Codable {
    public var _id: String = ""
    public var name: String = ""
    public var description: String = ""
    public var childId = [String]()
    public var referenceId: String = ""
    public var udcAnalytic = [UDCAnalytic]()
    public var udcRequirementStatusType = [String]()
    public var udcPriorityType = UDCPriorityType.None.name
}
