//
//  UDCSentenceGrammarPattern.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 22/01/19.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility

public class UDCSentenceGrammarPattern : Codable {
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var language: String = ""
    public var udcSentenceGrammarPatternData: [UDCSentenceGrammarPatternData] = [UDCSentenceGrammarPatternData]()
    
    public init() {
        
    }
    
    static public func getName() -> String {
        return "UDCSentenceGrammarPattern"
    }
    
    static public func get(udbcDatabaseOrm: UDBCDatabaseOrm, name: String, language: String) -> DatabaseOrmResult<UDCSentenceGrammarPattern> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        
        return databaseOrm.find(collectionName: UDCSentenceGrammarPattern.getName(), dictionary: ["idName": name, "language": language], limitedTo: 0) as DatabaseOrmResult<UDCSentenceGrammarPattern>
        
    }
    
    static public func get(udbcDatabaseOrm: UDBCDatabaseOrm, id: String, language: String) -> DatabaseOrmResult<UDCSentenceGrammarPattern> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        
        return databaseOrm.find(collectionName: UDCSentenceGrammarPattern.getName(), dictionary: ["_id": id, "language": language], limitedTo: 0) as DatabaseOrmResult<UDCSentenceGrammarPattern>
        
    }
}
