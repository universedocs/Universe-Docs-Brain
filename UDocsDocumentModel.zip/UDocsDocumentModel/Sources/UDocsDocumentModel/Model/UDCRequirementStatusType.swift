//
//  UDCRequirementStatusType.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 12/11/18.
//

import Foundation

public class UDCRequirementStatusType : Codable {
    static public var None = UDCRequirementStatusType("UDCRequirementStatusType.None", "None")
    static public var Completed = UDCRequirementStatusType("UDCRequirementStatusType.Completed", "Completed")
    static public var InProgress = UDCRequirementStatusType("UDCRequirementStatusType.InProgress", "In Progress")
    static public var Pending = UDCRequirementStatusType("UDCRequirementStatusType.Pending", "Pending")
    static public var Removed = UDCRequirementStatusType("UDCRequirementStatusType.Removed", "Removed")
    static public var InHold = UDCRequirementStatusType("UDCRequirementStatusType.Removed", "InHold")
    public var name: String = ""
    public var description: String = ""
    
    private init(_ name: String, _ description: String) {
        self.name = name
        self.description = description
    }
    
}
