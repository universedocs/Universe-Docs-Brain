//
//  UDCDocumentAccess.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 16/12/18.
//

import Foundation

public class UDCDocumentAccessHumanProfile : Codable {
    public var _id: String = ""
    public var upcHumanProfileId = [String]()
    // Access none means disabled. Examples: Read, Write, Delete, Share
    public var udcDocumentAccessType: String = "UDCDocumentAccessType.Read"
}
