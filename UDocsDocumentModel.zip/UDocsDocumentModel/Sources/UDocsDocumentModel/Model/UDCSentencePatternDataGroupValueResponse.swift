//
//  UDCSentencePatternDataGroupValueResponse.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 23/01/19.
//

import Foundation

public class UDCSentencePatternDataGroupValueResponse : Codable {
    public var _id: String = ""
    /// Grammar category the word belong to
    public var grammarCategory: String = ""
    /// The category that is percieved by the user
    public var endCategory: String = ""
    /// Is this value generated or from input
    public var isInput: Bool = false
    /// Value may be modified by grammar
    public var value: String = ""
    public var udcSentencePatternResponse: UDCSentencePatternResponse?
    
    public init() {
        
    }
}
