//
//  UDCDocumentView.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 17/11/18.
//

import Foundation

public class UDCDocumentView : Codable {
    public var _id: String = ""
    public var name: String = ""
    public var udcDocumentViewType = "UDCDocumentViewType.Regular"
    public var documentInformationModel: String = ""
    public var documentModel: String = ""
    public var documentChatModel: String = ""
    public var documentNotificationModel: String = ""
    public var documentHistoryModel: String = ""
    public var documentTestModel: String = ""
    
    public init() {
        
    }
}
