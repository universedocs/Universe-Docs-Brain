//
//  USCMailjetCredentials.swift
//  Universe_Docs_Security
//
//  Created by Kumar Muthaiah on 14/01/19.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility
import UDocsDatabaseUtility


public class UDCApplicationProgramInterface : Codable {
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var description: String = ""
    public var apiCompanyProfileIdName: String = ""
    public var senderEMail: String = ""
    public var senderName: String = ""
    public var apiUrl: String = ""
    public var userName: String = ""
    public var password: String = ""
    public var upcApplicationProfileId: String = ""
    public var upcCompanyProfileId: String = ""
    
    public init() {
        
    }
    
    static public func getName() -> String {
        return "UDCApplicationProgramInterface"
    }
    
    static public func get(udbcDatabaseOrm: UDBCDatabaseOrm, upcApplicationProfileId: String, upcCompanyProfileId: String, apiCompanyProfileIdName: String) -> DatabaseOrmResult<UDCApplicationProgramInterface> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let mongokittenOrmResult = databaseOrm.find(collectionName: UDCApplicationProgramInterface.getName(), dictionary: ["upcApplicationProfileId": upcApplicationProfileId, "upcCompanyProfileId": upcCompanyProfileId, "apiCompanyProfileIdName": apiCompanyProfileIdName], limitedTo: 0) as DatabaseOrmResult<UDCApplicationProgramInterface>
        
        return mongokittenOrmResult
    }
    
}
