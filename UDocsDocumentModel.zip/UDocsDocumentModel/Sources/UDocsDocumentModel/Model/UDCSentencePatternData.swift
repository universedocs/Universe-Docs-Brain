//
//  UDCDescriptionPatternData.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 14/11/18.
//

import Foundation

public class UDCSentencePatternData : Codable {
    public var _id: String = ""
    public var udcSentencePatternDataGroup = [UDCSentencePatternDataGroup]()
    
    public init() {
        
    }
}
