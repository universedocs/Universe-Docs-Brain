//
//  UDCViewItem.swift
//  Universe_Docs_View
//
//  Created by Kumar Muthaiah on 01/11/18.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility

public class UDCViewItem : Codable {
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var description: String = ""
    public var language: String = ""
    public var udcGrammarCategory: String = ""
    
    public init() {
        
    }
    
    public static func getName() -> String {
        return "UDCViewItem"
    }
    
    public static func get(_ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") -> DatabaseOrmResult<UDCViewItem> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getName(), dictionary: ["language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCViewItem>
        
        return databaseOrmResult
    }
    
    
}
