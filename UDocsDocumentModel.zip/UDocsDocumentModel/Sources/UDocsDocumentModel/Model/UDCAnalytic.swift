//
//  UDCAnalytic.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 12/11/18.
//

import Foundation

public class UDCAnalytic : Codable {
    public var _id: String = ""
    public var udcAnalyticItemCategoryIdName: String = ""
    public var udcAnalyticItemIdName: String = ""
    public var objectName: String = ""
    public var objectId: String = ""
    
    public init() {
        
    }
}
