//
//  UDCChildrenMap.swift
//  UDocsDocumentModel
//
//  Created by Kumar Muthaiah on 03/10/20.
//

import Foundation

public class UDCChildrenMap : Codable {
    public var name: String = ""
    public var id: String = ""
    
    public init() {
        
    }
}
