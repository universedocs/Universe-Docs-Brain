//
//  UDCSentenceGrammarPatternDataGroup.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 22/01/19.
//

import Foundation

public class UDCSentenceGrammarPatternDataGroup : Codable {
    public var _id: String = ""
    public var category: String = ""
    public var item: String? = ""
    public var tense: String = ""
    public var isSubject: Bool = false
    public var isVerb: Bool = false
    public var isNoun: Bool = false
    public var isAdjective: Bool = false
    public var valueType: String = ""
    public var itemState: String = ""
    // Nested sentence pattern
    public var udcSentenceGrammarPattern: UDCSentenceGrammarPattern?
    
    public init() {
        
    }
}
