//
//  UDCPhotoData.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 18/02/19.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility

public class UDCPhotoData : Codable {
    public var _id: String = ""
    public var data = Data()

    public init() {
        
    }
    
    public static func getName() -> String {
        return "UDCPhotoData"
    }
    
    static public func save<T: Codable>(collectionName: String, udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return databaseOrm.save(collectionName: collectionName, object: object )
        
    }
    
    static public func remove<T: Codable>(collectionName: String, udbcDatabaseOrm: UDBCDatabaseOrm, id: String) -> DatabaseOrmResult<T> {
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.remove(collectionName: collectionName, dictionary: ["_id": id])
        
    }
    
    public static func get(collectionName: String, id: String, _ udbcDatabaseOrm: UDBCDatabaseOrm) -> DatabaseOrmResult<UDCPhotoData> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: collectionName, dictionary: ["_id": id], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCPhotoData>
        return databaseOrmResult
    }
}
