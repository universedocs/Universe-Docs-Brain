//
//  UDCApplicationDocumentType.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 15/02/19.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility

public class UDCApplicationDocumentType : Codable {
    public var _id: String = ""
    public var udcProfile = [UDCProfile]()
    public var udcDocumentTypeIdName: String = ""
    
    public init() {
        
    }
  
    public static func getName() -> String {
        return "UDCApplicationDocumentType"
    }
    
    static public func save<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.save(collectionName: getName(), object: object )
        
    }
    
    public static func get(id: String, _ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") -> DatabaseOrmResult<UDCApplicationDocumentType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getName(), dictionary: ["_id": id,"language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCApplicationDocumentType>
        return databaseOrmResult
    }
    
    public static func get(limitedTo: Int, sortedBy: String,  udbcDatabaseOrm: UDBCDatabaseOrm, udcProfile: [UDCProfile]) -> DatabaseOrmResult<UDCApplicationDocumentType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        var all = [[String: Any]]()
        for udcp in udcProfile {
            if udcp.udcProfileItemIdName != "UDCProfileItem.Human" {
                let element: [String: Any] = ["udcProfileItemIdName": udcp.udcProfileItemIdName, "profileId": udcp.profileId]
                let elementMatch: [String: Any] = ["$elemMatch": element]
                all.append(elementMatch)
            }
        }
        let udcProfileAll: [String: Any] = ["$all": all]
        return databaseOrm.find(collectionName: UDCApplicationDocumentType.getName(), dictionary:
            ["udcProfile": udcProfileAll]
            , limitedTo: limitedTo, sortOrder: "UDBCSortOrder.Ascending", sortedBy: sortedBy) as DatabaseOrmResult<UDCApplicationDocumentType>
    }
    
    public static func get(limitedTo: Int, sortedBy: String,  udbcDatabaseOrm: UDBCDatabaseOrm, language: String = "en", _id: [String]) -> DatabaseOrmResult<UDCApplicationDocumentType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return databaseOrm.find(collectionName: UDCApplicationDocumentType.getName(), dictionary: ["$and":
            [
                ["language": language],
                ["_id": ["$in": _id]]
            ]],  limitedTo: limitedTo, sortOrder: "UDBCSortOrder.Ascending", sortedBy: sortedBy) as DatabaseOrmResult<UDCApplicationDocumentType>
    }
    
    
}
