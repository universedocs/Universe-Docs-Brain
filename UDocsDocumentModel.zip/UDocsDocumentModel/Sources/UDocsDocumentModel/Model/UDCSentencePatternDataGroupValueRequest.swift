//
//  UDCSentencePatternDataGroupValueRequest.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 23/01/19.
//

import Foundation

public class UDCSentencePatternDataGroupValueRequest : Codable {
    public var _id: String = ""
    public var endCategory: String = ""
    public var value: String = ""
    // Nested sentence pattern request
    public var udcSentencePatternRequest: UDCSentencePatternRequest?
    
    public init() {
        
    }
}
