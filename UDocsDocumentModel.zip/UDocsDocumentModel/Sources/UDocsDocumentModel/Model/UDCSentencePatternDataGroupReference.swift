//
//  UDCSentencePatternDataGroupReference.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 22/01/19.
//

import Foundation

public class UDCSentencePatternDataGroupReference : Codable {
    public var _id: String = ""
    public var path = [String]()
}
