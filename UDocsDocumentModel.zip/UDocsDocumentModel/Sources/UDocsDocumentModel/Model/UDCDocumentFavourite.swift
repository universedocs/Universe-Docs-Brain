//
//  UDCDocumentFavourite.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 13/09/19.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility

public class UDCDocumentFavourite : Codable {
    public var _id: String = ""
    public var upcHumanProfileId: String = ""
    public var upcApplicationProfileId: String = ""
    public var upcCompanyProfileId: String = ""
    public var udcDocumentId: String = ""
    public var udcDocumentTypeIdName: String = ""
    public var udcDocumentTime = UDCDocumentTime()
    
    public init() {
        
    }
    
    static public func getName() -> String {
        return "UDCDocumentFavourite"
    }
    
    static public func get(udbcDatabaseOrm: UDBCDatabaseOrm, id: String, language: String) -> DatabaseOrmResult<UDCDocumentFavourite> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        
        return databaseOrm.find(collectionName: getName(), dictionary: ["_id": id, "language": language], limitedTo: 0) as DatabaseOrmResult<UDCDocumentFavourite>
        
    }
    
    static public func update<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        let UDCDocumentFavourite = object as! UDCDocumentFavourite
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.update(collectionName: getName(), id: UDCDocumentFavourite._id, object: object )
        
    }
    
    static public func remove<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, udcDocumentId: String) -> DatabaseOrmResult<T> {
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.remove(collectionName: getName(), dictionary: ["udcDocumentId": udcDocumentId])
        
    }
    
    public static func get(upcHumanProfileId: String, upcApplicationProfileId: String, upcCompanyProfileId: String, limitedTo: Int, sortOrder: String, sortedBy: String,  udbcDatabaseOrm: UDBCDatabaseOrm, language: String = "en") -> DatabaseOrmResult<UDCDocumentFavourite> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return databaseOrm.find(collectionName: getName(), dictionary: ["upcHumanProfileId": upcHumanProfileId, "upcApplicationProfileId": upcApplicationProfileId, "upcCompanyProfileId": upcCompanyProfileId], projection: ["upcHumanProfileId", "upcApplicationProfileId", "upcCompanyProfileId", "udcDocumentId", "udcDocumentTypeIdName", "udcDocumentTime"], limitedTo: limitedTo, sortOrder: sortOrder, sortedBy: sortedBy) as DatabaseOrmResult<UDCDocumentFavourite>
    }
    
    public static func get(upcHumanProfileId: String, upcApplicationProfileId: String, upcCompanyProfileId: String, udcDocumentTypeIdName: String, limitedTo: Int, sortOrder: String, sortedBy: String,  udbcDatabaseOrm: UDBCDatabaseOrm, language: String = "en") -> DatabaseOrmResult<UDCDocumentFavourite> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return databaseOrm.find(collectionName: getName(), dictionary: ["upcHumanProfileId": upcHumanProfileId, "upcApplicationProfileId": upcApplicationProfileId, "upcCompanyProfileId": upcCompanyProfileId, "udcDocumentTypeIdName": udcDocumentTypeIdName], projection: ["upcHumanProfileId", "upcApplicationProfileId", "upcCompanyProfileId", "udcDocumentId", "udcDocumentTypeIdName", "udcDocumentTime"], limitedTo: limitedTo, sortOrder: sortOrder, sortedBy: sortedBy) as DatabaseOrmResult<UDCDocumentFavourite>
    }
    
    static public func save<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.save(collectionName: getName(), object: object )
        
    }
}
