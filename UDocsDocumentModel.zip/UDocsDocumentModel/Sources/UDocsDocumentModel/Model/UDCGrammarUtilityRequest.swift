//
//  UDCGrammarUtilityRequest.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 30/01/19.
//

import Foundation

public class UDCGrammarUtilityRequest : Codable {
    public var _id: String = ""
    public var category: String = ""
    public var categoryItem: String = ""
    public var language: String = ""
    public var udcGrammarItem = [UDCGrammarItem]()
    
    public init() {
        
    }
}
