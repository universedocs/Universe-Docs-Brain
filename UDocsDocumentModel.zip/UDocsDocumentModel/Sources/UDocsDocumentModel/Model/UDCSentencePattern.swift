//
//  UDCDescriptionPattern.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 14/11/18.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility

public class UDCSentencePattern : Codable {
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var language: String = ""
    public var sentence: String = ""
    public var udcSentencePatternData = [UDCSentencePatternData]()
    public var udcProfile = [UDCProfile]()
    public var udcAnalytic = [UDCAnalytic]()
    
    public init() {
        
    }
   
    
    static public func getName() -> String {
        return "UDCSentencePattern"
    }

    public static func get(_ idName: String, _ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") -> DatabaseOrmResult<UDCSentencePattern> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getName(), dictionary: ["idName": idName,"language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCSentencePattern>

        return databaseOrmResult
    }
    
    
    public static func get(limitedTo: Int, sortedBy: String,  udbcDatabaseOrm: UDBCDatabaseOrm, language: String = "en") -> DatabaseOrmResult<UDCSentencePattern> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return databaseOrm.find(collectionName: getName(), dictionary: ["language": language], projection: ["idName", "name", "language", "sentence", "udcSentencePatternData"], limitedTo: limitedTo, sortOrder: "UDBCSortOrder.Ascending", sortedBy: sortedBy) as DatabaseOrmResult<UDCSentencePattern>
    }
    
    public static func search(text: String, udbcDatabaseOrm: UDBCDatabaseOrm, language: String = "en") throws -> DatabaseOrmResult<UDCSentencePattern> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        
        let databaseOrmResult = databaseOrm.find(collectionName: getName(), dictionary: [
            
            "language": language,
            "name": try NSRegularExpression(pattern: text, options: .allowCommentsAndWhitespace)
            ], projection: ["idName", "name", "language", "sentence", "udcSentencePatternData"], limitedTo: 0, sortOrder: "UDBCSortOrder.Ascending", sortedBy: "name") as DatabaseOrmResult<UDCSentencePattern>
        
        return databaseOrmResult
    }
}
