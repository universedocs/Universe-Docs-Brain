//
//  UDCTextScriptType.swift
//  Universe_Docs_View
//
//  Created by Kumar Muthaiah on 31/10/18.
//

import Foundation

public class UDCTextScriptType : Codable {
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var description: String = ""
    
    public init() {
        
    }
}
