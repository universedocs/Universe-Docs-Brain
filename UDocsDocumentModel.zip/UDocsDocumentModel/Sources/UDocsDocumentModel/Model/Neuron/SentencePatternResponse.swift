//
//  SentencePatternResponse.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 25/11/18.
//

import Foundation


public class SentencePatternResponse : Codable {
    public var _id: String = ""
    public var udcSentencePattern = [UDCSentencePattern]()
    
}
