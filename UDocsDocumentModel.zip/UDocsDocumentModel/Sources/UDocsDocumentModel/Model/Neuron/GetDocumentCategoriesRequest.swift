//
//  GetDocumentCategoriesRequest.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 01/09/19.
//

import Foundation
import UDocsViewModel

public class GetDocumentCategoriesRequest : Codable {
    public var _id: String = ""
    public var categoryOptionViewModel = UVCOptionViewModel()
    public var documentLanguage: String = ""
    public var interfaceLanguage: String = ""
    public init() {
        
    }
}
