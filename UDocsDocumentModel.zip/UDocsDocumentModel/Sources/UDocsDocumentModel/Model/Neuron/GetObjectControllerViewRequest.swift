//
//  GetObjectControllerViewRequest.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 03/02/19.
//

import Foundation

public class GetObjectControllerViewRequest : Codable {
    public var _id: String = ""
    public var udcProfile = [UDCProfile]()
    public var documentLanguage: String = ""
    public var interfaceLanguage: String = ""
    
    public init() {
        
    }
}
