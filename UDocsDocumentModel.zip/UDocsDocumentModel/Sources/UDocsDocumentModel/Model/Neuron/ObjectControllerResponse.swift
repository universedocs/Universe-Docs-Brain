//
//  ObjectControllerResponse.swift
//  Universe Docs
//
//  Created by Kumar Muthaiah on 30/07/19.
//  Copyright © 2019 Universe Docs. All rights reserved.
//

import Foundation
import UDocsViewModel

public class ObjectControllerResponse : Codable {
    public var _id: String = ""
    public var viewGroup: String = ""
    public var viewConfigurationOptions = [UVCOptionViewModel]()
    public var viewConfigValue: String = ""
    public var udcViewItemName: String = ""
    public var udcViewItemId: String = ""
    public var groupUVCViewItemType: String = ""
    public var uvcViewItemType: String = ""
    public var viewConfigPathIdName = [String]()
    public var editMode: Bool = false
    
    public init() {
        
    }
}
