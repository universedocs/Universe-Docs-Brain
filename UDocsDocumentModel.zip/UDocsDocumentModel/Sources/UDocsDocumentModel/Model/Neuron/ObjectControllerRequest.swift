//
//  ObjectControllerRequest.swift
//  Universe Docs
//
//  Created by Kumar Muthaiah on 30/07/19.
//  Copyright © 2019 Universe Docs. All rights reserved.
//

import Foundation

public class ObjectControllerRequest : Codable {
    public var _id: String = ""
//    public var uvcObjectControllerEvent = UVCObjectControllerEvent()
    public var groupUVCViewItemType: String = ""
    public var udcViewItemName: String?
    public var udcViewItemId: String?
    public var uvcViewItemType: String = ""
    public var viewPathIdName = [String]()
    public var viewConfigPathIdName = [String]()
    public var udcDocumentTypeIdName: String = ""
    public var editMode: Bool = false

    public init() {
        
    }
}
