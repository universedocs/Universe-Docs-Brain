//
//  GetDocumentCategoryOptionsResponse.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 01/09/19.
//

import Foundation
import UDocsViewModel

public class GetDocumentCategoryOptionsResponse : Codable {
    public var _id: String = ""
    public var categoryOption = [String: [UVCOptionViewModel]]()
    
    public init() {
        
    }
}
