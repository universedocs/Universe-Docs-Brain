//
//  UDCApplicationHumanLanguage.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 17/11/19.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility

public class UDCApplicationHumanLanguage: Codable {
    public var _id: String = ""
    public var udcProfile = [UDCProfile]()
    public var udcHumanLanguageIdName: String = ""
    
    public init() {
        
    }
    
    public static func getName() -> String {
        return "UDCApplicationHumanLanguage"
    }
    
    public static func get(udcProfile: [UDCProfile], _ udbcDatabaseOrm: UDBCDatabaseOrm) -> DatabaseOrmResult<UDCApplicationHumanLanguage> {
           let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        var all = [[String: Any]]()
        for udcp in udcProfile {
            if udcp.udcProfileItemIdName != "UDCProfileItem.Human" {
                let element: [String: Any] = ["udcProfileItemIdName": udcp.udcProfileItemIdName, "profileId": udcp.profileId]
                let elementMatch: [String: Any] = ["$elemMatch": element]
                all.append(elementMatch)
            }
        }
        let udcProfileAll: [String: Any] = ["$all": all]
        let document: [String: Any] = ["udcProfile": udcProfileAll]
        let databaseOrmResult = databaseOrm.find(collectionName: getName(), dictionary: document, limitedTo: Int(0.0)) as DatabaseOrmResult<UDCApplicationHumanLanguage>
           return databaseOrmResult
       }
       
}
