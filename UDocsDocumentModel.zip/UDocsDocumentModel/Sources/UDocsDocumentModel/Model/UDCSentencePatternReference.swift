//
//  UDCSentencePatternReference.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 15/11/18.
//

import Foundation

public class UDCSentencePatternReference : Codable {
    public var _id: String = ""
    public var udcSentencePatternDataReference = [UDCSentencePatternDataReference]()
    
    public init() {
        
    }
}
