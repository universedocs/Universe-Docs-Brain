//
//  UDCProfile.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 11/02/19.
//

import Foundation

public class UDCProfile : Codable {
    public var _id: String = ""
    public var udcProfileItemIdName: String = ""
    public var profileId: String = ""
    
    public init() {
        
    }
    
}
