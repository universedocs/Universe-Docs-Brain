//
//  UDCWordPatternType.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 17/11/18.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility

public class UDCWordPatternType : Codable {
    static private var data = [String : UDCWordPatternType]()
    public var _id: String = ""
    public var idName: String = ""
    public var rootWordIdName: String = ""
    public var name: String = ""
    public var vowel = [String]()
    public var suffix = [String]()
    public var word = [String]()
    public var udcWordSuffixIdName = [String]()
    public var combineOrder = [String]()
    public var language: String = ""
    
    private init() {
        
    }
    
    public static func getName() -> String {
        return "UDCWordPatternType"
    }
    
    public static func getCollectionName() -> String {
        return "UDCWordPattern"
    }
    
    public static func get(greaterThenDescription: String, limitedTo: Int, sortedBy: String,   udbcDatabaseOrm: UDBCDatabaseOrm, language: String = "en") -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return databaseOrm.find(collectionName: UDCWordPatternType.getCollectionName(), dictionary: ["$and":
            [
                ["name": ["$gt": greaterThenDescription]],
                ["language": language]
            ]],  projection: ["idName", "rootWordIdName", "name", "language"], limitedTo: limitedTo, sortOrder: "UDBCSortOrder.Ascending", sortedBy: sortedBy) as DatabaseOrmResult<UDCWordPatternType>
    }
    
    public static func get(limitedTo: Int, sortedBy: String,  udbcDatabaseOrm: UDBCDatabaseOrm, language: String = "en") -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return databaseOrm.find(collectionName: UDCWordPatternType.getCollectionName(), dictionary:                 ["language": language]
            , projection: ["idName", "rootWordIdName", "name", "language"], limitedTo: limitedTo, sortOrder: "UDBCSortOrder.Ascending", sortedBy: sortedBy) as DatabaseOrmResult<UDCWordPatternType>
    }
    
    public static func search(text: String, udbcDatabaseOrm: UDBCDatabaseOrm, language: String = "en") throws -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        print(try NSRegularExpression(pattern: text, options: .caseInsensitive))
        let databaseOrmResult = databaseOrm.find(collectionName: UDCWordPatternType.getCollectionName(), dictionary: [
            
            "language": language,
            "name": try NSRegularExpression(pattern: text, options: .caseInsensitive)
            //            "name": [ "$regex": "\(text)*", "$options": "i"] as Document
            ], projection: ["idName", "rootWordIdName", "name", "language"], limitedTo: 0, sortOrder: "UDBCSortOrder.Ascending", sortedBy: "name") as DatabaseOrmResult<UDCWordPatternType>
        
        return databaseOrmResult
    }
    
    public static func get(_ name: String,  _ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") -> DatabaseOrmResult<UDCWordPatternType> {
        
        if data.count == 0 {
            let databaseOrmResult = get(udbcDatabaseOrm, language)
            for type in databaseOrmResult.object {
                data[type.rootWordIdName+"."+language] = type
            }
        }
        // If the type is not already found in memory, then get from database
        if data[name+"."+language] == nil {
            return getOne(name, udbcDatabaseOrm, language)
        }
        
        let databaseOrmResult = DatabaseOrmResult<UDCWordPatternType>()
        databaseOrmResult.object.append(data[name+"."+language]!)
        
        return databaseOrmResult
    }
    
    public static func get(id: String, _ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getCollectionName(), dictionary: ["_id": id,"language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCWordPatternType>
        return databaseOrmResult
    }
    
    public static func get(idName: String, _ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") throws -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getCollectionName(), dictionary: ["idName":  idName,"language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCWordPatternType>
        return databaseOrmResult
    }
    
    public static func get(rootWordIdName: String, name: String, _ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") throws -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getCollectionName(), dictionary: ["rootWordIdName": try NSRegularExpression(pattern: rootWordIdName, options: .caseInsensitive), "name": name,"language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCWordPatternType>
        return databaseOrmResult
    }
    
    public static func search(rootWordIdName: String, text: String, _ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") throws -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getCollectionName(), dictionary: ["rootWordIdName": try NSRegularExpression(pattern: rootWordIdName, options: .caseInsensitive), "name": try NSRegularExpression(pattern: text, options: .caseInsensitive),"language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCWordPatternType>
        return databaseOrmResult
    }

    public static func search(idName: String, text: String, _ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") throws -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getCollectionName(), dictionary: ["idName": try NSRegularExpression(pattern: idName, options: .caseInsensitive), "name": try NSRegularExpression(pattern: text, options: .caseInsensitive),"language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCWordPatternType>
        return databaseOrmResult
    }
    public static func getOne(_ name: String, _ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getCollectionName(), dictionary: ["name": name,"language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCWordPatternType>
        //        if databaseOrmResult.object.count > 0 {
        //            data[name+"."+language] = databaseOrmResult.object[0]
        //        }
        return databaseOrmResult
    }
    
    public static func get(_ udbcDatabaseOrm: UDBCDatabaseOrm, _ language: String = "en") -> DatabaseOrmResult<UDCWordPatternType> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        let databaseOrmResult = databaseOrm.find(collectionName: getCollectionName(), dictionary: ["language": language], limitedTo: Int(0.0)) as DatabaseOrmResult<UDCWordPatternType>
        data.removeAll()
        for type in databaseOrmResult.object {
            data[type.rootWordIdName+"."+language] = type
        }
        
        return databaseOrmResult
    }
}

