//
//  UDCSentencePatternRequest.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 23/01/19.
//

import Foundation

public class UDCSentencePatternRequest : Codable {
    public var _id: String = ""
    public var language: String = ""
    public var udcSentenceGrammarPatternId: String = ""
    public var udcSentencePatternDataRequest = [UDCSentencePatternDataRequest]()
    
    public init() {
        
    }
}
