//
//  UDCSentencePatternDataGroup.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 22/01/19.
//

import Foundation

public class UDCSentencePatternDataGroup : Codable {
    public var _id: String = ""
    public var category: String = ""
    public var item: String = ""
    public var itemType: String = ""
    public var udcSentencePatternDataGroupValue = [UDCSentencePatternDataGroupValue]()

    public init() {
        
    }
}
