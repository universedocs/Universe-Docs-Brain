//
//  UDCDocumentItemCount.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 12/11/18.
//

import Foundation

public class UDCDocumentItem : Codable {
    public var _id: String = ""
    public var type: String = ""
    public var value: String = ""
    
    public init() {
        
    }
}
