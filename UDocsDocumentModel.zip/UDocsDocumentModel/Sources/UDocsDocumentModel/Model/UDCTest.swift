//
//  UDCTest.swift
//  UDocsDocumentModel
//
//  Created by Kumar Muthaiah on 03/10/20.
//

import Foundation
import UDocsDatabaseUtility
import UDocsDatabaseModel
import UDocsMongoDatabaseUtility

public class UDCTest {
    public init() {
        
    }
    public func start() {
        //        changeTamilToTamil()
        //        addEdge(collectionName: "UDCDocumentMap")
        let idTa: [String] = ["5fb522110c3f4907f243afc9", "5fb526d30c3f4907f243b4a0", "5fb524140c3f4907f243b2dd", "5fb526c20c3f4907f243b3bc", "5fb526c60c3f4907f243b3f5", "5fb526cb0c3f4907f243b42e", "5fb526cf0c3f4907f243b467", "5fb526d30c3f4907f243b4a0", "5fb52c720c3f4907f243b4d9", "5fb52c880c3f4907f243b52a", "5fb52c9e0c3f4907f243b580", "5fb52ca50c3f4907f243b5b4", "5fb52ca90c3f4907f243b5ed", "5fb52cad0c3f4907f243b626", "5fb52cb60c3f4907f243b65f", "5fb52cc10c3f4907f243b6a6", "5fb52f8b0c3f4907f243b6df", "5fb52f8e0c3f4907f243b718", "5fb52f970c3f4907f243b751", "5fb52fac0c3f4907f243b78a", "5fb52fb10c3f4907f243b7c3", "5fb530b30c3f4907f243b7fc", "5fb530fb0c3f4907f243b86d", "5fb531000c3f4907f243b8a6", "5fb531060c3f4907f243b8df", "5fb5310b0c3f4907f243b918", "5fb531100c3f4907f243b951", "5fb5312f0c3f4907f243b9e8"]
        let idEn: [String] = ["5fb523f60c3f4907f243b2b6", "5fb526c10c3f4907f243b395", "5fb526c30c3f4907f243b3ce", "5fb526c70c3f4907f243b407", "5fb526cb0c3f4907f243b440", "5fb526d30c3f4907f243b4b2", "5fb52c8d0c3f4907f243b53c", "5fb52ca60c3f4907f243b5c6", "5fb52ca90c3f4907f243b5ff", "5fb52cae0c3f4907f243b638", "5fb52cb70c3f4907f243b671", "5fb52fb20c3f4907f243b7d5", "5fb530ea0c3f4907f243b838", "5fb530ff0c3f4907f243b87f", "5fb531020c3f4907f243b8b8", "5fb531070c3f4907f243b8f1", "5fb5310c0c3f4907f243b92a", "5fb531260c3f4907f243b9b3"]
        let fridEn = ["5fafa5c9c7d1a21a9d05d831"]
//        updateDocumentItemReference(id: fridEn, collectionName: "UDCFoodRecipe", udcDocumentTypeIdName: "UDCDocumentType.FoodRecipe")
        updateDocumentItemReference(id: idEn, collectionName: "UDCDocumentMap", udcDocumentTypeIdName: "UDCDocumentType.DocumentMap")
    }
    
    private func createDocumentItems(documentType: String, modelId: String, language: String) {
        var databaseOrm: DatabaseOrm = MongoDatabaseOrm()
        var udbcDatabaseOrm: UDBCDatabaseOrm = UDBCMongoDatabaseOrm()
        var udcProfileArray = [UDCProfile]()
        let udcProfile = UDCProfile()
        udcProfile.profileId = "UPCCompanyProfile.KumarMuthaiah"
        udcProfile.udcProfileItemIdName =  "UDCProfileItem.Company"
        udcProfileArray.append(udcProfile)
        udcProfile.profileId = "UPCApplicationProfile.UniverseDocs"
        udcProfile.udcProfileItemIdName = "UDCProfileItem.Application"
        udcProfileArray.append(udcProfile)
        udcProfile.profileId = "UPCHumanProfile.KumarMuthaiah"
        udcProfile.udcProfileItemIdName = "UDCProfileItem.Human"
        udcProfileArray.append(udcProfile)
        
        do {
            let databaesOrmResult = databaseOrm.connect(userName: DatabaseOrmConnection.username, password: DatabaseOrmConnection.password, host: DatabaseOrmConnection.host, port: DatabaseOrmConnection.port, databaseName: DatabaseOrmConnection.database)
            udbcDatabaseOrm.ormObject = databaseOrm as AnyObject
            udbcDatabaseOrm.type = UDBCDatabaseType.MongoDatabase.rawValue
            try UDCDocumentGraphModel.loadPredefinedGraphLabels(udbcDatabaseOrm: udbcDatabaseOrm)
            
            let databaseOrmResultmodel = UDCDocumentGraphModel.get(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, id: modelId)
            if databaseOrmResultmodel.databaseOrmError.count > 0 {
                print(databaseOrmResultmodel.databaseOrmError[0].description)
                return
            }
            let model = databaseOrmResultmodel.object[0]
            let databaseOrmResultmodelChild = UDCDocumentGraphModel.get(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, id: model.getChildrenEdgeId(language)[0])
            if databaseOrmResultmodelChild.databaseOrmError.count > 0 {
                print(databaseOrmResultmodelChild.databaseOrmError[0].description)
                return
            }
            let modelChild = databaseOrmResultmodelChild.object[0]
            let databaseOrmResultDocument = UDCDocument.get(udbcDatabaseOrm: udbcDatabaseOrm, udcDocumentTypeIdName: documentType, language: language)
            if databaseOrmResultDocument.databaseOrmError.count > 0 {
                print(databaseOrmResultDocument.databaseOrmError[0].description)
                return
            }
            let document = databaseOrmResultDocument.object
            for doc in document {
                let newModel = UDCDocumentGraphModel()
                let spdgvPhoto = UDCSentencePatternDataGroupValue()
                spdgvPhoto.udcDocumentId = doc._id
                spdgvPhoto.category = "UDCGrammarCategory.CommonNoun"
                spdgvPhoto.uvcViewItemType = "UVCViewItemType.Photo"
                spdgvPhoto.itemType = "UDCJson.String"
                spdgvPhoto.item = ""
                spdgvPhoto.itemId = ""
                spdgvPhoto.endCategoryId = ""
                spdgvPhoto.endCategoryIdName = "UDCDocumentItem.General"
                newModel.appendSentencePatternGroupValue(newValue: spdgvPhoto)
                if doc.language == "ta" {
                    let databaseOrmResultDocumentLan = UDCDocument.get(udbcDatabaseOrm: udbcDatabaseOrm, documentGroupId: doc.documentGroupId, notEqualsId: doc._id, language: "en")
                    if databaseOrmResultDocumentLan.databaseOrmError.count > 0 {
                        print(databaseOrmResultDocumentLan.databaseOrmError[0].description)
                        return
                    }
                    let documentLan = databaseOrmResultDocumentLan.object[0]
                    let databaseOrmResultmodelChildEn = UDCDocumentGraphModel.get(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, id: documentLan.udcDocumentGraphModelId)
                    if databaseOrmResultmodelChildEn.databaseOrmError.count > 0 {
                        print("Error in getting")
                        return
                    }
                    
                    let modelChildEn = databaseOrmResultmodelChildEn.object[0]
                    let spdgvEn = UDCSentencePatternDataGroupValue()
                    spdgvEn.udcDocumentId = doc._id
                    spdgvEn.category = "UDCGrammarCategory.CommonNoun"
                    spdgvEn.uvcViewItemType = "UVCViewItemType.Text"
                    spdgvEn.itemType = "UDCJson.String"
                    spdgvEn.item = modelChildEn.name
                    spdgvEn.itemId = modelChildEn._id
                    spdgvEn.endCategoryId = modelChildEn._id
                    spdgvEn.endCategoryIdName = modelChildEn.idName
                    let databaseOrmResultmodelChildChildEn = UDCDocumentGraphModel.get(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, id: modelChildEn.getChildrenEdgeId(modelChildEn.language)[0])
                    if databaseOrmResultmodelChildChildEn.databaseOrmError.count > 0 {
                        print("Error in getting")
                        return
                    }
                    let modelChildChildEn = databaseOrmResultmodelChildChildEn.object[0]
                    spdgvEn.itemId = modelChildChildEn._id
                    spdgvEn.itemIdName = modelChildChildEn.idName
                    newModel.appendSentencePatternGroupValue(newValue: spdgvEn)
                    
                    let spdgvInterfacePhoto = UDCSentencePatternDataGroupValue()
                    spdgvInterfacePhoto.udcDocumentId = doc._id
                    spdgvInterfacePhoto.category = "UDCGrammarCategory.CommonNoun"
                    spdgvInterfacePhoto.uvcViewItemType = "UVCViewItemType.Photo"
                    spdgvInterfacePhoto.item = ""
                    spdgvInterfacePhoto.itemId = ""
                    spdgvInterfacePhoto.itemType = "UDCJson.String"
                    spdgvInterfacePhoto.itemId = "5e1c861045627a5634112a71"
                    spdgvInterfacePhoto.itemIdName = "UDCDocumentItem.TranslationSeparator"
                    spdgvInterfacePhoto.endCategoryId = "5e1c852b45627a563411274e"
                    spdgvInterfacePhoto.endCategoryIdName = "UDCDocumentItem.DocumentInterfacePhoto"
                    newModel.appendSentencePatternGroupValue(newValue: spdgvInterfacePhoto)
                }

                let spdgv = UDCSentencePatternDataGroupValue()
                spdgv.category = "UDCGrammarCategory.CommonNoun"
                spdgv.uvcViewItemType = "UVCViewItemType.Text"
                spdgv.udcDocumentId = doc._id
                spdgv.endSubCategoryId = ""
                spdgv.endSubCategoryIdName = ""
                let databaseOrmResultmodelChild = UDCDocumentGraphModel.get(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, id: doc.udcDocumentGraphModelId)
                if databaseOrmResultmodelChild.databaseOrmError.count > 0 {
                    print("Error in getting")
                    return
                }
                    
                
                let modelChild = databaseOrmResultmodelChild.object[0]
                spdgv.endCategoryId = modelChild._id
                spdgv.endCategoryIdName = modelChild.idName
                let databaseOrmResultmodelChildChild = UDCDocumentGraphModel.get(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, id: modelChild.getChildrenEdgeId(modelChild.language)[0])
                if databaseOrmResultmodelChildChild.databaseOrmError.count > 0 {
                    print("Error in getting")
                    return
                }
                let modelChildChild = databaseOrmResultmodelChildChild.object[0]
                spdgv.itemId = modelChildChild._id
                spdgv.itemIdName = modelChildChild.idName
                spdgv.item = modelChildChild.name
                spdgv.itemId = modelChildChild._id
                newModel.appendSentencePatternGroupValue(newValue: spdgv)
                
                newModel._id = try udbcDatabaseOrm.generateId()
                newModel.name = modelChild.name
                newModel.idName = modelChild.idName
                newModel.language = modelChild.language
                newModel.udcProfile = modelChild.udcProfile
                newModel.udcDocumentTime = modelChild.udcDocumentTime
                let modelSave = UDCDocumentGraphModel.save(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, object: newModel)
                if modelSave.databaseOrmError.count > 0 {
                    print("Error in updating")
                    
                    return
                }
                
                model.appendEdgeId(UDCDocumentGraphModel.getGraphEdgeLabelId("UDCGraphEdgeLabel.Children", language), [newModel._id])
                let modelParentSave = UDCDocumentGraphModel.update(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, object: model)
                if modelParentSave.databaseOrmError.count > 0 {
                    print("Error in updating")
                    
                    return
                }
            }
        } catch {
            print(error)
        }
        
        defer {
            databaseOrm.disconnect()
        }
    }
    
    private func updateDocumentItemReference(id: [String], collectionName: String, udcDocumentTypeIdName: String) {
        var databaseOrm: DatabaseOrm = MongoDatabaseOrm()
        var udbcDatabaseOrm: UDBCDatabaseOrm = UDBCMongoDatabaseOrm()
        var udcProfileArray = [UDCProfile]()
        let udcProfile = UDCProfile()
        udcProfile.profileId = "UPCCompanyProfile.KumarMuthaiah"
        udcProfile.udcProfileItemIdName =  "UDCProfileItem.Company"
        udcProfileArray.append(udcProfile)
        udcProfile.profileId = "UPCApplicationProfile.UniverseDocs"
        udcProfile.udcProfileItemIdName = "UDCProfileItem.Application"
        udcProfileArray.append(udcProfile)
        udcProfile.profileId = "UPCHumanProfile.KumarMuthaiah"
        udcProfile.udcProfileItemIdName = "UDCProfileItem.Human"
        udcProfileArray.append(udcProfile)
        do {
            
            let databaesOrmResult = databaseOrm.connect(userName: DatabaseOrmConnection.username, password: DatabaseOrmConnection.password, host: DatabaseOrmConnection.host, port: DatabaseOrmConnection.port, databaseName: DatabaseOrmConnection.database)
            udbcDatabaseOrm.ormObject = databaseOrm as AnyObject
            udbcDatabaseOrm.type = UDBCDatabaseType.MongoDatabase.rawValue
            try UDCDocumentGraphModel.loadPredefinedGraphLabels(udbcDatabaseOrm: udbcDatabaseOrm)
            
            for i in id {
                let databaseOrmResultmodel = UDCDocumentGraphModel.get(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, id: i)
                if databaseOrmResultmodel.databaseOrmError.count > 0 {
                    print(databaseOrmResultmodel.databaseOrmError[0].description)
                    return
                }
                let model = databaseOrmResultmodel.object[0]
                let databaseOrmResultDocument = UDCDocument.get(udbcDatabaseOrm: udbcDatabaseOrm, udcProfile: udcProfileArray, idName: model.idName.replacingOccurrences(of: "UDCDocumentItem", with: "UDCDocument"), udcDocumentTypeIdName: udcDocumentTypeIdName, language: model.language)
                if databaseOrmResultDocument.databaseOrmError.count > 0 {
                    continue
                }
                let document = databaseOrmResultDocument.object[0]
                let databaseOrmResultDocumentEn = UDCDocument.get(udbcDatabaseOrm: udbcDatabaseOrm, udcProfile: udcProfileArray, idName: model.idName.replacingOccurrences(of: "UDCDocumentItem", with: "UDCDocument"), udcDocumentTypeIdName: udcDocumentTypeIdName, language: "en")
                let documentEn = databaseOrmResultDocumentEn.object[0]
                if document.idName == model.idName.replacingOccurrences(of: "UDCDocumentItem", with: "UDCDocument") && model.language == document.language {
                    if model.getSentencePatternDataGroupValue().count < 3 && model.language == "ta" {
                        continue
                    }
                    if model.getSentencePatternDataGroupValue().count < 2 && model.language == "en" {
                        continue
                    }
                    model.removeSentencePatternGroupValue()
                    let spdgvPhoto = UDCSentencePatternDataGroupValue()
                    spdgvPhoto.udcDocumentId = documentEn._id
                    spdgvPhoto.category = "UDCGrammarCategory.CommonNoun"
                    spdgvPhoto.uvcViewItemType = "UVCViewItemType.Photo"
                    spdgvPhoto.itemType = "UDCJson.String"
                    spdgvPhoto.item = ""
                    spdgvPhoto.itemId = ""
                    spdgvPhoto.endCategoryId = ""
                    spdgvPhoto.endCategoryIdName = "UDCDocumentItem.General"
                    model.appendSentencePatternGroupValue(newValue: spdgvPhoto)
                    print("Found: \(model.name): \(model.idName): \(model._id)")
                    if model.language == "ta" {
                        let databaseOrmResultmodelChildEn = UDCDocumentGraphModel.get(collectionName: collectionName, udbcDatabaseOrm: udbcDatabaseOrm, id: documentEn.udcDocumentGraphModelId)
                        if databaseOrmResultmodelChildEn.databaseOrmError.count > 0 {
                            print("Error in getting")
                            return
                        }
                        
                        let modelChildEn = databaseOrmResultmodelChildEn.object[0]
                        let spdgvEn = UDCSentencePatternDataGroupValue()
                        spdgvEn.udcDocumentId = documentEn._id
                        spdgvEn.category = "UDCGrammarCategory.CommonNoun"
                        spdgvEn.uvcViewItemType = "UVCViewItemType.Text"
                        spdgvEn.itemType = "UDCJson.String"
                        spdgvEn.item = modelChildEn.name
                        spdgvEn.itemId = modelChildEn._id
                        spdgvEn.endCategoryId = modelChildEn._id
                        spdgvEn.endCategoryIdName = modelChildEn.idName
                        let databaseOrmResultmodelChildChildEn = UDCDocumentGraphModel.get(collectionName: collectionName, udbcDatabaseOrm: udbcDatabaseOrm, id: modelChildEn.getChildrenEdgeId(modelChildEn.language)[0])
                        if databaseOrmResultmodelChildChildEn.databaseOrmError.count > 0 {
                            print("Error in getting")
                            return
                        }
                        let modelChildChildEn = databaseOrmResultmodelChildChildEn.object[0]
                        spdgvEn.itemId = modelChildChildEn._id
                        spdgvEn.itemIdName = modelChildChildEn.idName
                        model.appendSentencePatternGroupValue(newValue: spdgvEn)
                        
                        let spdgvInterfacePhoto = UDCSentencePatternDataGroupValue()
                        spdgvInterfacePhoto.udcDocumentId = documentEn._id
                        spdgvInterfacePhoto.category = "UDCGrammarCategory.CommonNoun"
                        spdgvInterfacePhoto.uvcViewItemType = "UVCViewItemType.Photo"
                        spdgvInterfacePhoto.item = ""
                        spdgvInterfacePhoto.itemId = ""
                        spdgvInterfacePhoto.itemType = "UDCJson.String"
                        spdgvInterfacePhoto.itemId = "5e1c861045627a5634112a71"
                        spdgvInterfacePhoto.itemIdName = "UDCDocumentItem.TranslationSeparator"
                        spdgvInterfacePhoto.endCategoryId = "5e1c852b45627a563411274e"
                        spdgvInterfacePhoto.endCategoryIdName = "UDCDocumentItem.DocumentInterfacePhoto"
                        model.appendSentencePatternGroupValue(newValue: spdgvInterfacePhoto)
                    }
                    
                    var spdgv = UDCSentencePatternDataGroupValue()
//                    if model.language == "en" {
//                        model.getSentencePatternGroupValue(wordIndex: 1)
//                    } else {
//                        model.getSentencePatternGroupValue(wordIndex: 3)
//                    }
                    spdgv.category = "UDCGrammarCategory.CommonNoun"
                    spdgv.uvcViewItemType = "UVCViewItemType.Text"
                    spdgv.udcDocumentId = document._id
                    spdgv.endSubCategoryId = ""
                    spdgv.endSubCategoryIdName = ""
                    let databaseOrmResultmodelChild = UDCDocumentGraphModel.get(collectionName: collectionName, udbcDatabaseOrm: udbcDatabaseOrm, id: document.udcDocumentGraphModelId)
                    if databaseOrmResultmodelChild.databaseOrmError.count > 0 {
                        print("Error in getting")
                        return
                    }
                    
                    let modelChild = databaseOrmResultmodelChild.object[0]
                    spdgv.endCategoryId = modelChild._id
                    spdgv.endCategoryIdName = modelChild.idName
                    let databaseOrmResultmodelChildChild = UDCDocumentGraphModel.get(collectionName: collectionName, udbcDatabaseOrm: udbcDatabaseOrm, id: modelChild.getChildrenEdgeId(modelChild.language)[0])
                    if databaseOrmResultmodelChildChild.databaseOrmError.count > 0 {
                        print("Error in getting")
                        return
                    }
                    let modelChildChild = databaseOrmResultmodelChildChild.object[0]
                    spdgv.itemId = modelChildChild._id
                    spdgv.itemIdName = modelChildChild.idName
                    spdgv.item = modelChildChild.name
                    spdgv.itemId = modelChildChild._id

//                    if model.language == "en" {
//                        model.removeSentencePatternGroupValue(wordIndex: 1)
//                    } else {
//                        model.removeSentencePatternGroupValue(wordIndex: 3)
//                    }
                    model.appendSentencePatternGroupValue(newValue: spdgv)
                    model.name = document.name
                    model.udcSentencePattern.sentence = document.name
                    let modelSave = UDCDocumentGraphModel.update(collectionName: "UDCDocumentItem", udbcDatabaseOrm: udbcDatabaseOrm, object: model)
                    if modelSave.databaseOrmError.count > 0 {
                        print("Error in updating")
                        
                        return
                    }

                } else {
                    print("NOT Found: \(model.getSentencePatternGroupValue(wordIndex: 1).item!): \(model.name)")
                }
                
            }
            //            }
        } catch {
            print(error)
        }
        
        defer {
            databaseOrm.disconnect()
        }
    }
    
    private func changeTamilToTamil() {
        var databaseOrm: DatabaseOrm = MongoDatabaseOrm()
        var udbcDatabaseOrm: UDBCDatabaseOrm = UDBCMongoDatabaseOrm()
        do {
            
            let databaesOrmResult = databaseOrm.connect(userName: DatabaseOrmConnection.username, password: DatabaseOrmConnection.password, host: DatabaseOrmConnection.host, port: DatabaseOrmConnection.port, databaseName: DatabaseOrmConnection.database)
            udbcDatabaseOrm.ormObject = databaseOrm as AnyObject
            udbcDatabaseOrm.type = UDBCDatabaseType.MongoDatabase.rawValue
            try UDCDocumentGraphModel.loadPredefinedGraphLabels(udbcDatabaseOrm: udbcDatabaseOrm)
            let collectionName = "UDCSwiftProgrammingLanguage"
            let documentType = "UDCDocumentType.SwiftProgrammingLanguage"
            let databaseOrmResultUDCDocumentGraphModel = UDCDocument.getAll(collectionName: "UDCDocument", udbcDatabaseOrm: udbcDatabaseOrm)
            if databaesOrmResult.databaseOrmError.count > 0 {
                print(databaesOrmResult.databaseOrmError[0].description)
                return
            }
            print("Size: \(databaseOrmResultUDCDocumentGraphModel.object.count): \(databaseOrmResultUDCDocumentGraphModel.object[databaseOrmResultUDCDocumentGraphModel.object.count - 1]._id)")
            let udcdm = databaseOrmResultUDCDocumentGraphModel.object
            for model in udcdm {
                if model.language == "ta" && model.udcDocumentTypeIdName == documentType {
                    print("Changing \(model.name)")
                    changeLanguageToLanguage(collectionName: collectionName, childrenId: [model.udcDocumentGraphModelId], udbcDatabaseOrm: udbcDatabaseOrm)
                }
            }
        } catch {
            print(error)
        }
        
        defer {
            databaseOrm.disconnect()
        }
    }
    
    private func changeLanguageToLanguage(collectionName: String, childrenId: [String], udbcDatabaseOrm: UDBCDatabaseOrm) {
        for id in childrenId {
            let databaseOrmResultModel = UDCDocumentGraphModel.get(collectionName: collectionName, udbcDatabaseOrm: udbcDatabaseOrm, id: id)
            if databaseOrmResultModel.databaseOrmError.count > 0 {
                print(databaseOrmResultModel.databaseOrmError[0].description)
                return
            }
            let modelData = databaseOrmResultModel.object[0]
            modelData.language = "ta"
            let databaseOrmResultSave = UDCDocumentGraphModel.update(collectionName: collectionName, udbcDatabaseOrm: udbcDatabaseOrm, object: modelData)
            if databaseOrmResultSave.databaseOrmError.count > 0 {
                print(databaseOrmResultSave.databaseOrmError[0].description)
                return
            }
            if modelData.getChildrenEdgeId("en").count > 0 {
                changeLanguageToLanguage(collectionName: collectionName, childrenId: modelData.getChildrenEdgeId("en"), udbcDatabaseOrm: udbcDatabaseOrm)
            }
        }
    }
    
    private func addEdge(collectionName: String) {
        var databaseOrm: DatabaseOrm = MongoDatabaseOrm()
        var udbcDatabaseOrm: UDBCDatabaseOrm = UDBCMongoDatabaseOrm()
        do {
            
            let databaesOrmResult = databaseOrm.connect(userName: DatabaseOrmConnection.username, password: DatabaseOrmConnection.password, host: DatabaseOrmConnection.host, port: DatabaseOrmConnection.port, databaseName: DatabaseOrmConnection.database)
            udbcDatabaseOrm.ormObject = databaseOrm as AnyObject
            udbcDatabaseOrm.type = UDBCDatabaseType.MongoDatabase.rawValue
            try UDCDocumentGraphModel1.loadPredefinedGraphLabels(udbcDatabaseOrm: udbcDatabaseOrm)
            let databaseOrmResultUDCDocumentGraphModel = UDCDocumentGraphModel1.getAll(collectionName: collectionName, udbcDatabaseOrm: udbcDatabaseOrm)
            if databaesOrmResult.databaseOrmError.count > 0 {
                print(databaesOrmResult.databaseOrmError[0].description)
                return
            }
            print("Size: \(databaseOrmResultUDCDocumentGraphModel.object.count): \(databaseOrmResultUDCDocumentGraphModel.object[databaseOrmResultUDCDocumentGraphModel.object.count - 1]._id)")
            let udcdm = databaseOrmResultUDCDocumentGraphModel.object
            for (modelIndex, model) in udcdm.enumerated() {
                print(model.name)
                //                if model.idName.hasSuffix("UDCDocumentItem.BasicDetail") {
                if model.childrenMap != nil {
                    model.childrenMap!.removeAll()
                }
                if model.parentMap != nil {
                    model.parentMap!.removeAll()
                }
                if model.edge != nil {
                    if model.edge!.count > 0 {
                        model.edge!.removeAll()
                    }
                }
                if model.parentId.count > 0 && ((model.childrenId == nil) || model.childrenId!.count == 0)  {
                    model.edge = [UDCDocumentGraphModel1.getGraphEdgeLabelId("UDCGraphEdgeLabel.Parent", model.language): model.parentId]
                } else
                if model.parentId.count == 0 && ((model.childrenId != nil) && model.childrenId!.count > 0)  {
                    model.edge = [UDCDocumentGraphModel1.getGraphEdgeLabelId("UDCGraphEdgeLabel.Children", model.language): model.childrenId!]
                } else
                if model.parentId.count > 0 && ((model.childrenId != nil) && model.childrenId!.count > 0) {
                    model.edge = [UDCDocumentGraphModel1.getGraphEdgeLabelId("UDCGraphEdgeLabel.Parent", model.language): model.parentId]
                    model.edge![UDCDocumentGraphModel1.getGraphEdgeLabelId("UDCGraphEdgeLabel.Children", model.language)] = model.childrenId!
                } else {
                    model.edge = [:]
                }
                print("Saving \(modelIndex)...")
                let result = UDCDocumentGraphModel1.update(collectionName: collectionName, udbcDatabaseOrm: udbcDatabaseOrm, object: model)
                if result.databaseOrmError.count > 0 {
                    print(result.databaseOrmError[0].description)
                    return
                }
                //                }
            }
        } catch {
            print(error)
        }
        
        defer {
            databaseOrm.disconnect()
        }
    }
    
}
