//
//  UDCDocumentItemMapMap.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 16/12/18.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility
import UDocsDatabaseModel
import UDocsDatabaseUtility
import UDocsDatabaseUtility

public class UDCDocumentItemMap : Codable {
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var udcDocumentItemMapNodeId = [String]()
    public var language: String = ""
    public var udcProfile = [UDCProfile]()

    public init() {
        
    }

    static public func getName() -> String {
        return "UDCDocumentItemMap"
    }
    
    static public func get(udbcDatabaseOrm: UDBCDatabaseOrm, id: String, language: String) -> DatabaseOrmResult<UDCDocumentItemMap> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        
        return databaseOrm.find(collectionName: UDCDocumentItemMap.getName(), dictionary: ["_id": id, "language": language], limitedTo: 0) as DatabaseOrmResult<UDCDocumentItemMap>
        
    }
    
    static public func get(udbcDatabaseOrm: UDBCDatabaseOrm, name: String, language: String) -> DatabaseOrmResult<UDCDocumentItemMap> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        
        return databaseOrm.find(collectionName: UDCDocumentItemMap.getName(), dictionary: ["idName": name, "language": language], limitedTo: 0) as DatabaseOrmResult<UDCDocumentItemMap>
        
    }
    
    static public func get(udbcDatabaseOrm: UDBCDatabaseOrm, idName: String, udcProfile: [UDCProfile], language: String) -> DatabaseOrmResult<UDCDocumentItemMap> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm

        var all = [[String: Any]]()
        for udcp in udcProfile {
            if udcp.udcProfileItemIdName != "UDCProfileItem.Human" {
                let element: [String: Any] = ["udcProfileItemIdName": udcp.udcProfileItemIdName, "profileId": udcp.profileId]
                let elementMatch: [String: Any] = ["$elemMatch": element]
                all.append(elementMatch)
            }
        }
        let udcProfileAll: [String: Any] = ["$all": all]
        return databaseOrm.find(collectionName: UDCDocumentItemMap.getName(), dictionary: ["idName": idName, "udcProfile": udcProfileAll, "language": language], limitedTo: 0) as DatabaseOrmResult<UDCDocumentItemMap>
        
    }
    
    static public func save<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.save(collectionName: UDCDocumentItemMap.getName(), object: object )
        
    }
    
    
    static public func update<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        let udcRecipe = object as! UDCDocumentItemMap
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.update(collectionName: UDCDocumentItemMap.getName(), id: udcRecipe._id, object: object )
        
    }
}
