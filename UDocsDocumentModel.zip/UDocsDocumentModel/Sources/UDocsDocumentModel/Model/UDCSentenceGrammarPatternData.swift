//
//  UDCSentenceGrammarPatternData.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 22/01/19.
//

import Foundation

public class UDCSentenceGrammarPatternData : Codable {
    public var _id: String = ""
    public var category: String = ""
    public var item: String? = ""
    public var valueType: String = ""
    public var udcSentenceGrammarPatternDataGroup = [UDCSentenceGrammarPatternDataGroup]()
    
    public init() {
        
    }
}
