//
//  UDCSentencePatternDataReference.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 15/11/18.
//

import Foundation

public class UDCSentencePatternDataReference : Codable {
    public var _id: String = ""
    public var orderNumber: Int = 0
    public var udcSentencePatternDataGroupReference = [UDCSentencePatternDataGroupReference]()
    
    public init() {
        
    }
}
