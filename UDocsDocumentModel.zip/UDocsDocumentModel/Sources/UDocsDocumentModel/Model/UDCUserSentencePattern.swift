//
//  UDCUserSentencePattern.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 11/02/19.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility
import UDocsDatabaseModel
import UDocsDatabaseUtility
import UDocsDatabaseUtility

public class UDCUserSentencePattern : Codable {
    public var _id: String = ""
    public var udcSentencePatternCategoryIdName: String = ""
    public var udcSentencePattern = UDCSentencePattern()
    public var udcAnalytic = [UDCAnalytic]()
    public var udcProfile = [UDCProfile]()
    
    public init() {
        
    }
    
    static public func getName() -> String {
        return "UDCUserSentencePattern"
    }
    
    static public func save<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.save(collectionName: UDCUserSentencePattern.getName(), object: object )
        
    }
}
