//
//  UDCSentencePatternDataGroupResponse.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 23/01/19.
//

import Foundation

public class UDCSentencePatternDataGroupResponse : Codable {
    public var _id: String = ""
    public var udcSentencePatternDataGroupValueResponse = [UDCSentencePatternDataGroupValueResponse]()
    
    public init() {
        
    }
}
