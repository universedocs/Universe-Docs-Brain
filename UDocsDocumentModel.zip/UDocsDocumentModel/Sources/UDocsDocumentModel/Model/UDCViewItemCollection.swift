//
//  UDCViewItemCollection.swift
//  Universe_Docs_View
//
//  Created by Kumar Muthaiah on 07/11/18.
//

import Foundation

public class UDCViewItemCollection : Codable {
    public var _id: String = ""
    public var udcChoice = [UDCChoice]()
    public var udcPhoto = [UDCPhoto]()
    public var udcSentenceReference = [UDCSentenceReference]()
    
    public init() {
        
    }
    
}
