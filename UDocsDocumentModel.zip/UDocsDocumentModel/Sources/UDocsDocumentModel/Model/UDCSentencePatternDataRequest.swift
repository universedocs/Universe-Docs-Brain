//
//  UDCSentencePatternDataRequest.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 23/01/19.
//

import Foundation

public class UDCSentencePatternDataRequest : Codable {
    public var _id: String = ""
    public var orderNumber: Int = 1
    public var udcSentencePatternDataGroupRequest = [UDCSentencePatternDataGroupRequest]()
    
    public init() {
        
    }
}
