//
//  UDCGraphEdgeLabel.swift
//  UDocsDocumentModel
//
//  Created by Kumar Muthaiah on 19/10/20.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility
import UDocsDatabaseUtility

public class UDCGraphEdgeLabel : Codable {
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var language: String = ""
    
    public init() {
        
    }
    
    public static func getAll(udbcDatabaseOrm: UDBCDatabaseOrm) -> DatabaseOrmResult<UDCGraphEdgeLabel> {
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.getAll(collectionName: "UDCGraphEdgeLabel")
    }
    
    public static func getGraphEdgeLabelId(udcGraphEdgeLabel: [UDCGraphEdgeLabel], idName: String, language: String) -> String {
        for label in udcGraphEdgeLabel {
            if label.idName == idName && label.language == language {
                return label._id
            }
        }
        
        return ""
    }
    
}
