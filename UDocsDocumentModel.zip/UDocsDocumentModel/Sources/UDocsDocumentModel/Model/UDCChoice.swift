//
//  UDCChoice.swift
//  Universe Docs View
//
//  Created by Kumar Muthaiah on 12/02/19.
//

import Foundation

public class UDCChoice : Codable {
    public var _id: String = ""
    public var name: String = ""
    public var udcChoiceItem = [UDCChoiceItem]()
    public var selectedItemIndex = [Int]()
    public var isEditable: Bool = false
    public var isSingleChoice: Bool = false
    public var isMultipleChoice: Bool = false
    public var isExpanded: Bool = false
    public var isCollapsed: Bool = false
    public var parentId = [String]()
    public var childrenId = [String]()
    public var path = [String]()
    
    public init() {
        
    }
    
    public static func getName() -> String {
        return "UDCChoice"
    }
    
}
