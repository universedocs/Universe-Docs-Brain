//
//  UDCRequirementDocumentItemType.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 12/11/18.
//

import Foundation

public class UDCRequirementDocumentItemType : Codable {
    static public var None = UDCRequirementDocumentItemType("UDCRequirementDocumentItemType.None", "None")
    static public var TotalRequirements = UDCRequirementDocumentItemType("UDCRequirementDocumentItemType.TotalRequirements", "Total Requirements")
    public var name: String = ""
    public var description: String = ""
    
    private init(_ name: String, _ description: String) {
        self.name = name
        self.description = description
    }
    
}
