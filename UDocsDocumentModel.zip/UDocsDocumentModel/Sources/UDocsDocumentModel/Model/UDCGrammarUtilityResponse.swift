//
//  UDCGrammarUtilityResponse.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 30/01/19.
//

import Foundation

public class UDCGrammarUtilityResponse : Codable {
    public var _id: String = ""
    public var udcSentenceGrammarPattern = UDCSentenceGrammarPattern()
    public var udcSentencePatternRequest = UDCSentencePatternRequest()
    
    public init() {
        
    }
}
