//
//  UDCDescriptionPatternCategory.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 14/11/18.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility

public class UDCSentencePatternCategory : Codable {
    public var _id: String = ""
    public var name: String = ""
    public var description: String = ""
    public var language: String = ""
    
    public init() {
        
    }
    
    static public func getName() -> String {
        return "UDCSentencePatternCategory"
    }
    
    static public func get(udbcDatabaseOrm: UDBCDatabaseOrm, name: String, language: String) -> DatabaseOrmResult<UDCSentencePatternCategory> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        
        return databaseOrm.find(collectionName: UDCSentencePatternCategory.getName(), dictionary: ["name": name, "language": language], limitedTo: 0) as DatabaseOrmResult<UDCSentencePatternCategory>
        
    }
    
    static func save<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.save(collectionName: UDCSentencePatternCategory.getName(), object: object )
        
    }
    
    
}
