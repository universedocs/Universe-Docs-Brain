//
//  UDCAnalyticItem.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 11/02/19.
//

import Foundation

public class UDCAnalyticItemCategory : Codable {
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var language: String = ""
    
    public init() {
        
    }
}
