//
//  UDCSentencePatternExample.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 26/11/18.
//

import Foundation

public class UDCSentencePatternExample : Codable {
    public var udcSentencePatternData = [UDCSentencePatternData]()
    
    public init() {
        
    }
}
