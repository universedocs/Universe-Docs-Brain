//
//  UDCDocumentAccess.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 16/12/18.
//

import Foundation

public class UDCDocumentAccessProfile : Codable {
    public var _id: String = ""
    public var profileId: String = ""
    public var udcProfileItemIdName: String = ""
    public var udcDocumentAccessType = [String]()
    public var udcDocumentRoleType = [String]()
    
    public init() {
        
    }
}
