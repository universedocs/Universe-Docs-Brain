//
//  UDCMeasurement.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 13/11/18.
//

import Foundation

public class UDCMeasurement : Codable {
    public var _id: String = ""
    // Of or Using what? Cup, Spoon, etc.,
    public var type: String = ""
    // How much milliliter?, etc.,
    public var value: Double = 0.0
    // Milliliter, Teaspoon, etc.,
    public var unitType: String = ""
    
    public init() {
        
    }
}
