//
//  UDCChoiceItem.swift
//  Universe Docs View
//
//  Created by Kumar Muthaiah on 12/02/19.
//

import Foundation

public class UDCChoiceItem : Codable {
    public var _id: String = ""
    public var udcSentenceReference = UDCSentenceReference()

    public init() {
        
    }
}
