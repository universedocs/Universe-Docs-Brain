//
//  UDCMathematicalItem.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 30/01/19.
//

import Foundation

public class UDCMathematicalItem : Codable {
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var udcGrammarCategoryIdName = [String]()
    public var language: String = ""
    
    public init() {
        
    }
    
    
}
