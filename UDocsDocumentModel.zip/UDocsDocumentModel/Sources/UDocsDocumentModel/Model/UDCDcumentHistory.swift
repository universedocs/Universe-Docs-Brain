//
//  UDCDcumentHistory.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 15/12/18.
//

import Foundation

public class UDCDcumentHistory : Codable {
    public var _id: String = ""
    public var version: String = ""
    public var time: Date?
    public var humanProfileId: String = ""
    public var reason: String = ""
    
    public init() {
        
    }
}
