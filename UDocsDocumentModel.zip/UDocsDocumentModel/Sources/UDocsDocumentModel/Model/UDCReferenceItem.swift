//
//  File.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 22/11/18.
//

import Foundation

public class UDCReferenceItem : Codable {
    public var _id: String = ""
    public var objectName: String = ""
    public var path: String = ""
    public var value: String = ""
    public var count: Int
}
