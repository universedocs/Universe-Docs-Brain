//
//  UDCHumanLanguage.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 29/04/19.
//

import Foundation
// https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes

public class UDCHumanLanguage : Codable {
    static private var data = [String : UDCHumanLanguageType]()
    public var _id: String = ""
    public var idName: String = ""
    public var name: String = ""
    public var alternateName: [String]? = [String]()
    public var code6392: String? = ""
    public var code6393: String? = ""
    public var code6395: String? = ""
    public var code6391: String? = ""
    public var nativeName: [String]? = [String]()
    public var otherName: [String]? = [String]()
    public var language: String = ""
    
    public init() {
        
    }
 
    
}
