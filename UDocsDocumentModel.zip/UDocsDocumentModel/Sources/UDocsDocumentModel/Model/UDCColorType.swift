//
//  UDCColorType.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 12/11/18.
//

import Foundation

public class UDCColorType {
    static public var None = UDCColorType("UDCColorType.None", "None")
    static public var DarkGreen = UDCColorType("UDCColorType.DarkGreen", "DarkGreen")
    static public var DarkBlue = UDCColorType("UDCColorType.DarkBlue", "Dark Blue")
    static public var DarkRed = UDCColorType("UDCColorType.DarkRed", "Dark Red")
    public var name: String = ""
    public var description: String = ""
    
    private init(_ name: String, _ description: String) {
        self.name = name
        self.description = description
    }
    
}
