//
//  UDCDocumentItemGraphReference.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 24/06/19.
//

import Foundation

public class UDCDocumentItemGraphReference : Codable {
    public var _id: String = ""
    /// Document id. If not id, then same document
    public var documentId: String = ""
    /// Type of document reference
    public var udcDocumentReferenceTypeIdName: String = ""
    public var nodeId: String = ""
    public var referenceSentenceIndex: Int = 0
    public var referenceItemIndex: Int = 0
    /// API id for REST interface, in case used in another application.
    /// Update the value in those applications also.
    public var udcApplicationProgramInterfaceIdName: String?
    
    public init() {
        
    }
}
