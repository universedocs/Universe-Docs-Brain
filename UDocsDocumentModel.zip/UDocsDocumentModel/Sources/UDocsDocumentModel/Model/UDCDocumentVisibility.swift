//
//  UDCDocumentVisibility.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 16/12/18.
//

import Foundation

public class UDCDocumentVisibility : Codable {
    public var _id: String = ""
    public var udcDocumentVisibilityHumanProfile = [UDCDocumentVisibilityHumanProfile]()
}
