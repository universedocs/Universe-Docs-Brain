//
//  File.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 25/02/20.
//

import Foundation

public class UDCButton : Codable {
    public var _id: String = ""
    public var name: String = ""
    public var groupId: String = ""
    public var isSelected: Bool = false
    public var isMultipleChoice: Bool = false
    public var isSingleChoice: Bool = false
    public var unSelectedPhotoId: String?
    public var selectedPhotoId: String?
    
    
    public init() {
        
    }
}
