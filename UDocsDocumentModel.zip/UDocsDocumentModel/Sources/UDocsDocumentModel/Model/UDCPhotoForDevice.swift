//
//  UDCPhotoForDevice.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 23/02/20.
//

import Foundation

public class UDCPhotoForDevice : Codable {
    public var _id: String = ""
    public var deviceId: String = ""
    public var deviceIdName: String = ""
    // Points to UDCPhoto
    public var udcPhotoId: String = ""
}
