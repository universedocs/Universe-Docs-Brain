//
//  UDCSentencePatternDataResponse.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 23/01/19.
//

import Foundation

public class UDCSentencePatternDataResponse : Codable {
    public var _id: String = ""
    public var orderNumber: Int = 1
    public var udcSentencePatternDataGroupResponse = [UDCSentencePatternDataGroupResponse]()
    
    public init() {
        
    }
}
