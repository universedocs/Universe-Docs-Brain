//
//  UDCSentenceReference.swift
//  Universe Docs Brain
//
//  Created by Kumar Muthaiah on 07/08/19.
//

import Foundation

public class UDCSentenceReference : Codable {
    public var _id: String = ""
    public var name: String = ""
    public var startSentenceIndex: Int = 0
    public var startItemIndex: Int = 0
    public var endSentenceIndex: Int = 0
    public var endItemIndex: Int = 0
    public var objectName: String = ""
    public var objectId: String = ""

    public init() {
        
    }
}
