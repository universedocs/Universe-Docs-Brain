//
//  UDCPriority.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 12/11/18.
//

import Foundation

public class UDCPriorityType {
    static public var None = UDCPriorityType("UDCDocumentItemType.None", "None")
    static public var High = UDCPriorityType("UDCDocumentItemType.High", "High")
    static public var Medium = UDCPriorityType("UDCDocumentItemType.Medium", "Medium")
    static public var Low = UDCPriorityType("UDCDocumentItemType.Low", "Low")
    static public var VeryLow = UDCPriorityType("UDCDocumentItemType.VeryLow", "Very Low")
    public var name: String = ""
    public var description: String = ""
    
    private init(_ name: String, _ description: String) {
        self.name = name
        self.description = description
    }
    
}
