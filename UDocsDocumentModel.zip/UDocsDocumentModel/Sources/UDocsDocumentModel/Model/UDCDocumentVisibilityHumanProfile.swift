//
//  UDCDocumentVisibilityHumanProfile.swift
//  Universe_Docs_Document
//
//  Created by Kumar Muthaiah on 16/12/18.
//

import Foundation

public class UDCDocumentVisibilityHumanProfile : Codable {
    public var _id: String = ""
    public var upcHumanProfileId = [String]()
    // Examples: Public, Restricted
    public var udcDocumentVisibilityType: String = "UDCDocumentVisibilityType.Restricted"
}
