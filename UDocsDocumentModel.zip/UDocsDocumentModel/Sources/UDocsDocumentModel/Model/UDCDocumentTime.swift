//
//  UDCDocumentTime.swift
//  Universe Docs Document
//
//  Created by Kumar Muthaiah on 11/02/19.
//

import Foundation
import UDocsDatabaseModel
import UDocsDatabaseUtility


public class UDCDocumentTime : Codable {
    public var _id: String = ""
    public var creationTime: Date?
    public var createdBy: String = ""
    public var changedTime: Date?
    public var changedBy: String?
    public var removedTime: Date?
    public var removedBy: String?
    public var language: String = ""
    
    public init() {
        
    }
    
    
    static public func getName() -> String {
        return "UDCDocumentTime"
    }
    
    static public func get(udbcDatabaseOrm: UDBCDatabaseOrm, id: String, language: String) -> DatabaseOrmResult<UDCDocumentTime> {
        let databaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        
        return databaseOrm.find(collectionName: UDCDocumentTime.getName(), dictionary: ["_id": id, "language": language], limitedTo: 0) as DatabaseOrmResult<UDCDocumentTime>
        
    }
    
    static public func update<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        let udcDocumentTime = object as! UDCDocumentTime
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.update(collectionName: UDCDocumentTime.getName(), id: udcDocumentTime._id, object: object )
        
    }
    
    
    static public func update<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, id: String, changedTime: Date, changedBy: String) -> DatabaseOrmResult<T> {
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.update(collectionName: UDCDocumentTime.getName(), whereDictionary: ["_id": id], setDictionary: ["changedTime": changedTime, "changedBy": changedBy])
        
    }
    static public func save<T: Codable>(udbcDatabaseOrm: UDBCDatabaseOrm, object: T) -> DatabaseOrmResult<T> {
        
        let DatabaseOrm = udbcDatabaseOrm.ormObject as! DatabaseOrm
        return DatabaseOrm.save(collectionName: UDCDocumentTime.getName(), object: object )
        
    }
    
}
